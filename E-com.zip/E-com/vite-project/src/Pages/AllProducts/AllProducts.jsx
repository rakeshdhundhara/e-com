import React from 'react'

function AllProducts() {
  return (
    <div>AllProducts</div>
  )
}

export default AllProducts;